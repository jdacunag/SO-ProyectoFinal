"Notas personales del proyecto" 
