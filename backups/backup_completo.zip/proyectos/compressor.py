"def comprimir_archivos(): pass" 
