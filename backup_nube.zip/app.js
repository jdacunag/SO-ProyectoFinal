"Codigo fuente principal del proyecto" 
